<?php
	
	$dbhost = 'mysql.hostinger.es';
	$dbuser = 'u196760225_pre';
	$dbpass = 'e1p3k3';
	$dbname = 'u196760225_pre';

?>